document.addEventListener('DOMContentLoaded', function() {
    const uploadArea = document.getElementById('uploadArea');
    const serviceUpload = document.getElementById('service-upload');
    const servicesGrid = document.getElementById('servicesGrid');
    const addServiceBtn = document.getElementById('addService');
    
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', function() {
        this.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        this.classList.remove('dragover');
        
        if (e.dataTransfer.files.length) {
            serviceUpload.files = e.dataTransfer.files;
        }
    });
    
    addServiceBtn.addEventListener('click', function() {
        const name = document.getElementById('serviceName').value;
        const price = document.getElementById('servicePrice').value;
        const duration = document.getElementById('serviceDuration').value;
        
        if (!name || !price) {
            alert('Please fill in at least the service name and price');
            return;
        }
        
        createServiceCard(name, price, duration);
    });
    
    function createServiceCard(name, price, duration) {
        const serviceId = Date.now();
        
        let serviceHTML = `
        <div class="service-card" data-id="${serviceId}">
            ${serviceUpload.files.length ? 
                `<img src="${URL.createObjectURL(serviceUpload.files[0])}" class="service-image" alt="${name}">` : 
                `<div class="service-image" style="background: linear-gradient(135deg, #3498db, #2c3e50);"></div>`
            }
            <div class="service-content">
                <button class="like-btn" data-liked="false">
                    <i class="far fa-heart"></i>
                </button>
                <span class="like-count">0</span>
                <div class="service-name">${name}</div>
                <div class="service-details">
                    <span class="service-price">${price}</span>
                    ${duration ? `<span class="service-duration">${duration}</span>` : ''}
                </div>
            </div>
        </div>
        `;
        
        servicesGrid.insertAdjacentHTML('beforeend', serviceHTML);
        
        document.getElementById('serviceName').value = '';
        document.getElementById('servicePrice').value = '';
        document.getElementById('serviceDuration').value = '';
        serviceUpload.value = '';
        
        const newLikeBtn = document.querySelector(`.service-card[data-id="${serviceId}"] .like-btn`);
        newLikeBtn.addEventListener('click', toggleLike);
    }
    
    function toggleLike(e) {
        const likeBtn = e.currentTarget;
        const isLiked = likeBtn.getAttribute('data-liked') === 'true';
        const likeCountElement = likeBtn.nextElementSibling;
        let likeCount = parseInt(likeCountElement.textContent);
        
        if (isLiked) {
            likeBtn.innerHTML = '<i class="far fa-heart"></i>';
            likeBtn.setAttribute('data-liked', 'false');
            likeCount--;
        } else {
            likeBtn.innerHTML = '<i class="fas fa-heart"></i>';
            likeBtn.setAttribute('data-liked', 'true');
            likeCount++;
        }
        
        likeCountElement.textContent = likeCount;
    }
    
    const mediaUpload = document.getElementById('media-upload');
    const mediaPreview = document.getElementById('media-preview');
    const addMediaBtn = document.getElementById('add-Media');
    
    mediaUpload.addEventListener('change', function(e) {
        const files = e.target.files;
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const fileType = file.type.split('/')[0];
            
            const mediaItem = document.createElement('div');
            mediaItem.className = 'media-item';
            
            if (fileType === 'image') {
                const img = document.createElement('img');
                img.src = URL.createObjectURL(file);
                mediaItem.appendChild(img);
            } else if (fileType === 'video') {
                const video = document.createElement('video');
                video.src = URL.createObjectURL(file);
                video.controls = true;
                mediaItem.appendChild(video);
            }
            
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-media';
            deleteBtn.innerHTML = '×';
            deleteBtn.addEventListener('click', function() {
                mediaItem.remove();
            });
            
            mediaItem.appendChild(deleteBtn);
            mediaPreview.appendChild(mediaItem);
        }
        
        mediaUpload.value = '';
    });
    
    const profileUpload = document.getElementById('image-upload');
    const profileImage = document.getElementById('profile-image');
    
    profileUpload.addEventListener('change', function(e) {
        if (e.target.files.length) {
            const reader = new FileReader();
            reader.onload = function(event) {
                profileImage.src = event.target.result;
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const profileUpload = document.getElementById('image-upload');
    const profileImage = document.getElementById('profile-image');
    
    profileUpload.addEventListener('change', function(e) {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = function(event) {
                profileImage.src = event.target.result;
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    });
    
    profileImage.addEventListener('click', function() {
        profileUpload.click();
    });
});

document.getElementById('sub_button').addEventListener('click', sub_buttonClick);
function sub_buttonClick(){
    alert("You have Successfully Subscribed");
}

/*
document.getElementById('view-profile').addEventListener('click',open_Profile)

function open_Profile(){
    window.open("PROFILES.html", "_blank");
}
    */