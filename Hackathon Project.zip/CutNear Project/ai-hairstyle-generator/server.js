const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json({ limit: "10mb" }));

// Your HuggingFace API key - KEEP THIS SECRET!
const HUGGINGFACE_API_KEY = "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"; // Your actual key

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'Server is running' });
});

// Main HuggingFace face-preserving hairstyle generation
app.post("/generate-hairstyle", async (req, res) => {
  const { imageBase64, gender, hairstyleType, color, description } = req.body;

  if (!imageBase64) {
    return res.status(400).json({ success: false, error: "No image uploaded" });
  }

  try {
    console.log(`Generating ${hairstyleType} hairstyle with ${color} color...`);

    // Clean the base64 data
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-z]+;base64,/, '');
    
    // Convert base64 to buffer
    const imageBuffer = Buffer.from(cleanBase64, 'base64');

    // Create the prompt for face-preserving hairstyle change
    const instruction = `Change this person's hairstyle to a ${hairstyleType} with ${color} hair color while keeping the exact same face and facial features. ${description || 'Make it look professional and realistic.'}`;

    // Try instruct-pix2pix first (best for image editing)
    try {
      console.log('Trying instruct-pix2pix model...');
      
      const response = await axios.post(
        "https://api-inference.huggingface.co/models/timbrooks/instruct-pix2pix",
        imageBuffer,
        {
          headers: {
            "Authorization": `Bearer ${HUGGINGFACE_API_KEY}`,
            "Content-Type": "application/octet-stream",
          },
          params: {
            prompt: instruction,
            num_inference_steps: 20,
            image_guidance_scale: 1.2,
            guidance_scale: 7.5
          },
          responseType: 'arraybuffer',
          timeout: 30000
        }
      );

      if (response.data && response.data.byteLength > 1000) {
        const base64Image = `data:image/png;base64,${Buffer.from(response.data).toString('base64')}`;
        console.log('✅ Success with instruct-pix2pix');
        return res.json({ success: true, image: base64Image, model: "instruct-pix2pix" });
      }
    } catch (error) {
      console.log('instruct-pix2pix failed:', error.message);
    }

    // Fallback to stable-diffusion-2-inpainting
    try {
      console.log('Trying stable-diffusion-2-inpainting...');
      
      const response = await axios.post(
        "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2-inpainting",
        imageBuffer,
        {
          headers: {
            "Authorization": `Bearer ${HUGGINGFACE_API_KEY}`,
            "Content-Type": "application/octet-stream",
          },
          params: {
            prompt: `professional headshot photo of the same person with ${hairstyleType} hairstyle, ${color} hair color, maintain exact facial features`,
            negative_prompt: "blurry, low quality, distorted face, different person, multiple people, cartoon",
            num_inference_steps: 25,
            guidance_scale: 7.5
          },
          responseType: 'arraybuffer',
          timeout: 30000
        }
      );

      if (response.data && response.data.byteLength > 1000) {
        const base64Image = `data:image/png;base64,${Buffer.from(response.data).toString('base64')}`;
        console.log('✅ Success with stable-diffusion-inpainting');
        return res.json({ success: true, image: base64Image, model: "stable-diffusion-inpainting" });
      }
    } catch (error) {
      console.log('stable-diffusion-inpainting failed:', error.message);
    }

    // Final fallback to demo mode
    console.log('All AI models failed, falling back to demo mode');
    return generateDemoImage(req, res);

  } catch (error) {
    console.error("HuggingFace generation error:", error.message);
    
    // Provide helpful error messages
    let errorMessage = "AI generation failed. Using demo mode instead.";
    if (error.response?.status === 401) {
      errorMessage = "Invalid HuggingFace API key";
    } else if (error.response?.status === 503) {
      errorMessage = "AI models are loading. Trying demo mode...";
    } else if (error.response?.status === 429) {
      errorMessage = "Rate limit exceeded. Using demo mode...";
    }

    console.log(`Falling back to demo mode: ${errorMessage}`);
    return generateDemoImage(req, res);
  }
});

// Demo generation function
function generateDemoImage(req, res) {
  const { imageBase64, gender, hairstyleType, color, description } = req.body;
  
  // Create enhanced demo with face overlay
  const demoSVG = `
    <svg width="400" height="500" viewBox="0 0 400 500" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <!-- Pattern for original face -->
        <pattern id="originalFace" patternUnits="objectBoundingBox" width="1" height="1">
          <image href="${imageBase64}" x="0" y="0" width="160" height="200" preserveAspectRatio="xMidYMid slice"/>
        </pattern>
        
        <!-- Gradient for hair -->
        <radialGradient id="hairGradient" cx="50%" cy="30%" r="70%">
          <stop offset="0%" style="stop-color:${
            color === 'blonde' ? '#FFD700' : 
            color === 'brown' ? '#8B4513' : 
            color === 'red' ? '#CD5C5C' : 
            color === 'white' ? '#F5F5F5' : 
            '#2F4F4F'
          };stop-opacity:1" />
          <stop offset="100%" style="stop-color:${
            color === 'blonde' ? '#B8860B' : 
            color === 'brown' ? '#654321' : 
            color === 'red' ? '#B22222' : 
            color === 'white' ? '#DCDCDC' : 
            '#1C1C1C'
          };stop-opacity:1" />
        </radialGradient>
      </defs>
      
      <!-- Background -->
      <rect width="400" height="500" fill="linear-gradient(135deg, #f5f5f5, #e0e0e0)"/>
      
      <!-- Neck/Body -->
      <rect x="150" y="280" width="100" height="180" fill="#FDBCB4" rx="10"/>
      
      <!-- Face using original image -->
      <ellipse cx="200" cy="200" rx="80" ry="100" fill="url(#originalFace)" stroke="#ddd" stroke-width="2"/>
      
      <!-- Hair based on selected style -->
      ${hairstyleType === 'fade' || hairstyleType === 'Fade' ? `
        <!-- Fade: Short sides, longer top -->
        <ellipse cx="200" cy="130" rx="85" ry="50" fill="url(#hairGradient)"/>
        <ellipse cx="200" cy="140" rx="70" ry="35" fill="url(#hairGradient)" opacity="0.8"/>
        <ellipse cx="200" cy="150" rx="55" ry="25" fill="url(#hairGradient)" opacity="0.6"/>
      ` : hairstyleType === 'buzz-cut' || hairstyleType === 'Buzz Cut' ? `
        <!-- Buzz cut: Very short all around -->
        <ellipse cx="200" cy="135" rx="82" ry="45" fill="url(#hairGradient)" opacity="0.9"/>
      ` : hairstyleType === 'pompadour' || hairstyleType === 'Low fade' ? `
        <!-- Pompadour: High and swept back -->
        <ellipse cx="200" cy="110" rx="75" ry="55" fill="url(#hairGradient)"/>
        <ellipse cx="200" cy="100" rx="65" ry="40" fill="url(#hairGradient)" opacity="0.8"/>
        <path d="M 140 130 Q 200 80 260 130" fill="url(#hairGradient)" opacity="0.9"/>
      ` : hairstyleType === 'afro' || hairstyleType === 'Afro' ? `
        <!-- Afro: Round and full -->
        <circle cx="200" cy="135" r="90" fill="url(#hairGradient)"/>
        <circle cx="200" cy="135" r="75" fill="url(#hairGradient)" opacity="0.7"/>
      ` : hairstyleType === 'braids' || hairstyleType === 'Braids' ? `
        <!-- Braids: Textured patterns -->
        <ellipse cx="200" cy="125" rx="85" ry="55" fill="url(#hairGradient)"/>
        <path d="M 130 120 Q 200 110 270 120" stroke="${color === 'blonde' ? '#FFD700' : '#2F4F4F'}" stroke-width="3" fill="none"/>
        <path d="M 135 140 Q 200 130 265 140" stroke="${color === 'blonde' ? '#FFD700' : '#2F4F4F'}" stroke-width="3" fill="none"/>
        <path d="M 140 160 Q 200 150 260 160" stroke="${color === 'blonde' ? '#FFD700' : '#2F4F4F'}" stroke-width="3" fill="none"/>
      ` : hairstyleType === 'bald' || hairstyleType === 'Bald' ? `
        <!-- Bald: Just the head shape -->
        <ellipse cx="200" cy="135" rx="82" ry="50" fill="#FDBCB4" opacity="0.8"/>
      ` : `
        <!-- Default: Standard cut -->
        <ellipse cx="200" cy="120" rx="88" ry="60" fill="url(#hairGradient)"/>
      `}
      
      <!-- Face features overlay (subtle) -->
      <ellipse cx="185" cy="185" rx="8" ry="12" fill="rgba(255,255,255,0.3)"/> <!-- Left eye highlight -->
      <ellipse cx="215" cy="185" rx="8" ry="12" fill="rgba(255,255,255,0.3)"/> <!-- Right eye highlight -->
      
      <!-- Labels and info -->
      <rect x="20" y="350" width="360" height="120" fill="rgba(255,255,255,0.9)" rx="10" stroke="#ddd"/>
      <text x="200" y="375" text-anchor="middle" font-size="18" font-weight="bold" fill="#333">
        Face-Preserving ${hairstyleType}
      </text>
      <text x="200" y="395" text-anchor="middle" font-size="14" fill="#666">
        ${color.charAt(0).toUpperCase() + color.slice(1)} hair color
      </text>
      <text x="200" y="415" text-anchor="middle" font-size="12" fill="#999">
        Original facial features preserved
      </text>
      <text x="200" y="435" text-anchor="middle" font-size="11" fill="#007acc">
        Demo Mode - AI models may be loading
      </text>
      <text x="200" y="455" text-anchor="middle" font-size="10" fill="#aaa">
        This shows how face-preserving AI would work
      </text>
    </svg>
  `;

  const demoImage = `data:image/svg+xml;base64,${Buffer.from(demoSVG).toString('base64')}`;

  res.json({ 
    success: true, 
    image: demoImage,
    message: "Demo mode with face preservation preview",
    isDemo: true
  });
}

// Test endpoint to check if HuggingFace API is working
app.get("/test-huggingface", async (req, res) => {
  try {
    const response = await axios.get(
      "https://api-inference.huggingface.co/models/timbrooks/instruct-pix2pix",
      {
        headers: {
          "Authorization": `Bearer ${HUGGINGFACE_API_KEY}`,
        },
      }
    );

    res.json({ 
      success: true, 
      message: "HuggingFace API connection successful",
      modelStatus: response.status === 200 ? "Ready" : "Loading"
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message,
      message: "HuggingFace API connection failed - check your API key"
    });
  }
});

// Enhanced demo endpoint
app.post("/generate-hairstyle-demo", async (req, res) => {
  console.log('Demo endpoint called');
  setTimeout(() => generateDemoImage(req, res), 2000);
});

app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log('\n🔑 API Key Status: Configured');
  console.log('📝 Test your setup:');
  console.log('1. Visit: http://localhost:3000/test-huggingface');
  console.log('2. Upload a photo and try generation');
  console.log('\n🔗 Available Endpoints:');
  console.log('  POST /generate-hairstyle     (Main AI generation with demo fallback)');
  console.log('  POST /generate-hairstyle-demo (Pure demo mode)');
  console.log('  GET  /test-huggingface       (Test API connection)');
  console.log('  GET  /health                 (Health check)');
  console.log('\n✨ Features:');
  console.log('  - Real AI generation when models are ready');
  console.log('  - Automatic fallback to enhanced demo mode');
  console.log('  - Face-preserving preview with original photo');
});

module.exports = app;