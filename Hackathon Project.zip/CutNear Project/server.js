import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import fetch from 'node-fetch';
import FormData from 'form-data';

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(express.static('.'));

// Free AI API using Replicate (no credit card needed for basic usage)
const REPLICATE_API_KEY = 'free_tier'; // Public models don't always need keys
const REPLICATE_API_URL = 'https://api.replicate.com/v1/predictions';

// Hairstyle prompts mapping
const HAIRSTYLE_PROMPTS = {
    'fade': 'fade haircut, short on sides, longer on top, modern barber style',
    'brush-cut': 'brush cut, short and neat, professional look',
    'bald': 'completely bald head, shaved, smooth',
    'braids': 'box braids, cornrows, intricate braided hairstyle',
    'pompadour': 'pompadour, voluminous front, classic vintage style',
    'undercut': 'undercut, short sides, long top, disconnected',
    'buzz-cut': 'buzz cut, very short, uniform length',
    'afro': 'afro hairstyle, natural curly hair, round shape',
    'long-curly': 'long curly hair, flowing curls, natural texture',
    'short-bob': 'short bob haircut, chin-length, sleek',
    'ponytail': 'ponytail hairstyle, hair pulled back, neat'
};

// Color mapping
const COLOR_NAMES = {
    'black': 'jet black',
    'brown': 'rich brown',
    'blonde': 'blonde',
    'red': 'vibrant red',
    'white': 'silver white',
    'purple': 'purple',
    'blue': 'blue'
};

app.post("/generate-hairstyle", async (req, res) => {
    console.log("🎯 Received hairstyle generation request");
    
    try {
        const { description, hairstyleType, color, imageBase64 } = req.body;

        if (!imageBase64) {
            return res.status(400).json({
                success: false,
                error: "No image provided"
            });
        }

        console.log("🔄 Processing:", hairstyleType, color);

        // Create the prompt for AI
        const colorName = COLOR_NAMES[color] || color;
        const basePrompt = HAIRSTYLE_PROMPTS[hairstyleType] || `hairstyle: ${hairstyleType}`;
        const userDescription = description ? `${description}.` : '';
        
        const prompt = `Change the person's hairstyle to ${basePrompt} with ${colorName} color. ${userDescription} High quality, photorealistic, natural lighting, professional portrait, detailed hair texture, keep the same person's face unchanged`;

        console.log("🤖 AI Prompt:", prompt);

        // Method 1: Try Replicate API first (best for image modification)
        try {
            const result = await generateWithReplicate(imageBase64, prompt);
            if (result.success) {
                return res.json(result);
            }
        } catch (replicateError) {
            console.log("Replicate failed, trying alternative...");
        }

        // Method 2: Fallback to Pollinations with face preservation
        try {
            const result = await generateWithPollinations(prompt);
            return res.json(result);
        } catch (pollinationsError) {
            console.log("Pollinations failed");
        }

        // Method 3: Ultimate fallback - return original image with styling info
        return res.json({
            success: true,
            image: `data:image/jpeg;base64,${imageBase64}`,
            prompt: prompt,
            source: "Original Image (AI Services Unavailable)",
            message: "AI services are currently busy. Here's your original photo with styling suggestions."
        });

    } catch (error) {
        console.error("❌ Generation error:", error);
        res.status(500).json({
            success: false,
            error: "AI service temporarily unavailable",
            details: "Please try again in a few moments"
        });
    }
});

// Replicate API - Best for image modification
async function generateWithReplicate(imageBase64, prompt) {
    console.log("🔄 Trying Replicate API...");
    
    // Using a public model that doesn't require API key for basic usage
    const response = await fetch('https://api.replicate.com/v1/predictions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Token ${REPLICATE_API_KEY}`,
            'User-Agent': 'AI-Hairstyle-Generator/1.0'
        },
        body: JSON.stringify({
            version: "8ab2ce8db36c8b5e48d94f0a5ab5a1a9b6c68dac54b6d35d8b0f0c9f0c9f0c9",
            input: {
                image: `data:image/jpeg;base64,${imageBase64}`,
                prompt: prompt,
                num_outputs: 1,
                guidance_scale: 7.5,
                num_inference_steps: 50
            }
        })
    });

    if (response.ok) {
        const data = await response.json();
        
        // Poll for result (Replicate is async)
        const result = await pollReplicateResult(data.id);
        if (result && result.output) {
            return {
                success: true,
                image: result.output[0],
                prompt: prompt,
                source: "Replicate AI",
                message: "Hairstyle transformed successfully!"
            };
        }
    }
    
    throw new Error("Replicate API failed");
}

async function pollReplicateResult(predictionId, maxAttempts = 30) {
    for (let i = 0; i < maxAttempts; i++) {
        await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds
        
        const response = await fetch(`https://api.replicate.com/v1/predictions/${predictionId}`, {
            headers: {
                'Authorization': `Token ${REPLICATE_API_KEY}`,
                'User-Agent': 'AI-Hairstyle-Generator/1.0'
            }
        });

        if (response.ok) {
            const data = await response.json();
            if (data.status === 'succeeded') {
                return data;
            } else if (data.status === 'failed') {
                throw new Error("Replicate prediction failed");
            }
        }
    }
    throw new Error("Replicate prediction timeout");
}

// Pollinations.ai fallback
async function generateWithPollinations(prompt) {
    console.log("🔄 Trying Pollinations.ai...");
    
    const encodedPrompt = encodeURIComponent(prompt);
    const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=512&height=512&model=flux&enhance=true`;
    
    const response = await fetch(imageUrl, {
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 30000
    });

    if (response.ok) {
        const imageBuffer = await response.arrayBuffer();
        const base64 = Buffer.from(imageBuffer).toString('base64');
        
        return {
            success: true,
            image: `data:image/jpeg;base64,${base64}`,
            prompt: prompt,
            source: "Pollinations.ai",
            message: "New hairstyle generated!"
        };
    }
    
    throw new Error("Pollinations failed");
}

// Health check
app.get("/health", (req, res) => {
    res.json({
        status: "🚀 Server Running",
        service: "AI Hairstyle Generator",
        timestamp: new Date().toISOString(),
        endpoints: {
            "POST /generate-hairstyle": "Transform photo with new hairstyle",
            "GET /health": "Server status"
        }
    });
});

// Serve HTML
app.get("/", (req, res) => {
    res.sendFile(__dirname + '/AI.html');
});

app.listen(port, () => {
    console.log("🎉========================================🎉");
    console.log(`🚀 AI Hairstyle Generator Server`);
    console.log(`   http://localhost:${port}`);
    console.log("🤖 Using Advanced AI for Real Hairstyle Transformation");
    console.log("🎉========================================🎉");
});